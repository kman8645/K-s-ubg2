<?php
/**
 * Attogram Games
 * https://github.com/attogram/games
 *
 * Website Configuration
 */

// Title - for <title> - text only, no HTML
$title = 'Attogram Games';

// Headline - text and/or HTML
$headline = 'Attogram Games';
