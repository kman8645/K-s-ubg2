# Future Developments

* build steps: check `game['require']` requirements exists or skip game
* Create /about.html page during build
* .htaccess 404, 503 setup
* add .favicon
* javascript-piano @TODO - clean repo - rm twitter codes
* html5-hearts @TODO - clean repo - rm google analytics
* raging-gardens @TODO - clean repo - rm facebook calls
* hexgl-lite @TODO - clean repo - rm google analytics, use local favicons
* tower @TODO - clean repo - rm google analytics
* particle-clicker @TODO - clean repo - rm google analytics
* taptaptap @TODO - clean repo - rm google analytics, google tags
* pond @TODO - rm or use local copy of kik cards.js
* the-house @TODO - clean repo - rm google analytics
